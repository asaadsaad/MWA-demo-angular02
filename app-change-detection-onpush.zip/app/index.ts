export * from './app.component';
export * from './app.module';


var name = "Asaad";